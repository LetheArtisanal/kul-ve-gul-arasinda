export default function Home() {
  return <h1>Kül ve Gül Arasında</h1>;
}